# Seyd‑Yaar (صیدیار)
